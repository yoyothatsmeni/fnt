<?php
	class_exists('XenForo_Application', false) || die('Invalid');

	$__extraData['title'] = 'Page Not Found';
?>

The page you requested could not be found.